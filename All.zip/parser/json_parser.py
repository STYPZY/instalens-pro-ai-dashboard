import json
import os


def load_json_file(path):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None


def extract_usernames(data):
    """
    Instagram JSON exports store usernames inside nested structures.
    This safely extracts them.
    """
    usernames = []

    if isinstance(data, list):
        for entry in data:
            if isinstance(entry, dict):
                for key in entry:
                    value = entry[key]
                    if isinstance(value, list):
                        for item in value:
                            if isinstance(item, dict):
                                if "value" in item:
                                    usernames.append(item["value"])
                                elif "string_list_data" in item:
                                    for v in item["string_list_data"]:
                                        if "value" in v:
                                            usernames.append(v["value"])

    return usernames


def merge_split_files(folder, prefix):
    """
    Merge split Instagram exports:
    followers_1.json
    followers_2.json
    """
    merged = []

    files = sorted([
        f for f in os.listdir(folder)
        if f.startswith(prefix) and f.endswith(".json")
    ])

    for file in files:
        path = os.path.join(folder, file)
        data = load_json_file(path)
        if data:
            merged.extend(extract_usernames(data))

    return merged


def parse_json_export(folder):

    followers = merge_split_files(folder, "followers")
    following = merge_split_files(folder, "following")

    likes = merge_split_files(folder, "liked_posts")
    comments = merge_split_files(folder, "comments")

    return {
        "followers": list(set(followers)),
        "following": list(set(following)),
        "likes": likes,
        "comments": comments
    }