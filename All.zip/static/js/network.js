const container = document.getElementById("network")

const nodes = new vis.DataSet([
{id:1,label:"You"}
])

const edges = new vis.DataSet([])

const data = {
nodes:nodes,
edges:edges
}

const options = {

physics:{
barnesHut:{
gravitationalConstant:-8000
}
},

interaction:{
dragNodes:true,
zoomView:true
}

}

const network = new vis.Network(container,data,options)