document.addEventListener("DOMContentLoaded",function(){

const followers = window.dashboard_data.followers.length
const following = window.dashboard_data.following.length

const likes = window.dashboard_data.likes.length
const comments = window.dashboard_data.comments.length

createRelationshipChart(followers,following)

createInteractionChart(likes,comments)

})